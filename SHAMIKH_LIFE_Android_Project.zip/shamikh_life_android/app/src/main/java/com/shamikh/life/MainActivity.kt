package com.shamikh.life

import android.Manifest
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF10110F)
private val Panel = Color(0xFF1B1D19)
private val Gold = Color(0xFFD6B66D)
private val Muted = Color(0xFFAAA99F)
private val White = Color(0xFFF5F1E7)

 data class TaskItem(val id: Long, val title: String, val time: Long, val done: Boolean)
 data class GoalItem(val id: Long, val title: String, val period: String, val progress: Int)

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { ShamikhApp() }
    }
}

@Composable
fun ShamikhApp() {
    val context = LocalContext.current
    var tab by remember { mutableStateOf("الرئيسية") }
    var tasks by remember { mutableStateOf(loadTasks(context)) }
    var goals by remember { mutableStateOf(loadGoals(context)) }
    var showTask by remember { mutableStateOf(false) }
    var showGoal by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Bg, surface = Panel, onBackground = White, onSurface = White)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Gold) {
                listOf("الرئيسية", "المهام", "الأهداف", "العبادات", "المزيد").forEach { label ->
                    NavigationBarItem(selected = tab == label, onClick = { tab = label }, icon = {
                        Icon(when(label) { "الرئيسية" -> Icons.Default.Dashboard; "المهام" -> Icons.Default.CheckCircle; "الأهداف" -> Icons.Default.Flag; "العبادات" -> Icons.Default.MenuBook; else -> Icons.Default.Apps }, null)
                    }, label = { Text(label, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, selectedTextColor = Gold, indicatorColor = Color(0xFF353023), unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }, floatingActionButton = {
            if (tab == "المهام" || tab == "الرئيسية") FloatingActionButton(onClick = { showTask = true }, containerColor = Gold, contentColor = Bg) { Icon(Icons.Default.Add, "إضافة مهمة") }
            if (tab == "الأهداف") FloatingActionButton(onClick = { showGoal = true }, containerColor = Gold, contentColor = Bg) { Icon(Icons.Default.Add, "إضافة هدف") }
        }) { padding ->
            when(tab) {
                "الرئيسية" -> Dashboard(Modifier.padding(padding), tasks, goals, onDone = { id -> tasks = tasks.map { if(it.id==id) it.copy(done=!it.done) else it }; saveTasks(context,tasks) }, onAdd = { showTask = true })
                "المهام" -> TasksScreen(Modifier.padding(padding), tasks, onDone = { id -> tasks = tasks.map { if(it.id==id) it.copy(done=!it.done) else it }; saveTasks(context,tasks) })
                "الأهداف" -> GoalsScreen(Modifier.padding(padding), goals)
                "العبادات" -> WorshipScreen(Modifier.padding(padding))
                else -> MoreScreen(Modifier.padding(padding))
            }
        }
        if(showTask) AddTaskDialog(onDismiss = { showTask = false }, onSave = { title, time ->
            val item = TaskItem(System.currentTimeMillis(), title, time, false)
            tasks = (tasks + item).sortedBy { it.time }; saveTasks(context,tasks); scheduleReminder(context,item); showTask = false
        })
        if(showGoal) AddGoalDialog(onDismiss = { showGoal = false }, onSave = { title, period -> goals = goals + GoalItem(System.currentTimeMillis(),title,period,0); saveGoals(context,goals); showGoal = false })
    }
}

@Composable
fun Dashboard(modifier: Modifier, tasks: List<TaskItem>, goals: List<GoalItem>, onDone:(Long)->Unit, onAdd:()->Unit) {
    val today = SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar")).format(Date())
    val done = tasks.count { it.done }
    LazyColumn(modifier.fillMaxSize().padding(horizontal=18.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(top=24.dp,bottom=24.dp)) {
        item { Text("SHAMIKH LIFE", color=Gold, fontSize=13.sp, fontWeight=FontWeight.Bold, letterSpacing=3.sp); Text("حياتك… بخطة واضحة", color=White, fontSize=26.sp, fontWeight=FontWeight.Bold); Text(today, color=Muted) }
        item { Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(20.dp)) { Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) { Text("إنجاز اليوم", color=Muted); Text("$done / ${tasks.size} مهمة", color=White, fontSize=25.sp, fontWeight=FontWeight.Bold); LinearProgressIndicator(progress={ if(tasks.isEmpty()) 0f else done.toFloat()/tasks.size }, color=Gold, trackColor=Color(0xFF38382F), modifier=Modifier.fillMaxWidth().height(8.dp)); Text(if(tasks.isEmpty()) "ابدأ بإضافة أول مهمة ليومك" else "واصل التقدم، كل خطوة مهمة", color=Gold) } } }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) { Text("مهام اليوم", color=White, fontSize=18.sp, fontWeight=FontWeight.Bold); Text("إضافة +", color=Gold, modifier=Modifier.clickable { onAdd() }) } }
        if(tasks.isEmpty()) item { EmptyCard("لا توجد مهام بعد", "أضف أول مهمة وحدد وقت التذكير") }
        items(tasks.take(5), key={it.id}) { TaskRow(it,onDone) }
        item { Text("أهدافك النشطة", color=White, fontSize=18.sp, fontWeight=FontWeight.Bold) }
        if(goals.isEmpty()) item { EmptyCard("لا توجد أهداف مسجلة", "حوّل طموحاتك إلى أهداف قابلة للقياس") }
        items(goals.take(3), key={it.id}) { GoalRow(it) }
    }
}

@Composable fun TasksScreen(modifier: Modifier, tasks: List<TaskItem>, onDone:(Long)->Unit) {
    Column(modifier.fillMaxSize().padding(18.dp)) { Text("المهام والمواعيد", color=White, fontSize=24.sp, fontWeight=FontWeight.Bold); Text("رتّب يومك ونفّذ الأهم أولاً", color=Muted); Spacer(Modifier.height(16.dp)); if(tasks.isEmpty()) EmptyCard("قائمة المهام فارغة", "اضغط + لإضافة مهمة مع تنبيه") else LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)) { items(tasks,key={it.id}) { TaskRow(it,onDone) } } }
}
@Composable fun GoalsScreen(modifier: Modifier, goals: List<GoalItem>) {
    Column(modifier.fillMaxSize().padding(18.dp)) { Text("الأهداف", color=White, fontSize=24.sp, fontWeight=FontWeight.Bold); Text("من الرؤية طويلة الأمد إلى خطوة اليوم", color=Muted); Spacer(Modifier.height(16.dp)); if(goals.isEmpty()) EmptyCard("ابدأ بتحديد هدف", "سنقسم أهدافك لاحقاً إلى خطوات ومراحل") else LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)) { items(goals,key={it.id}) { GoalRow(it) } } }
}
@Composable fun WorshipScreen(modifier: Modifier) {
    val items = listOf("أذكار الصباح" to "بعد صلاة الفجر", "أذكار المساء" to "بعد العصر أو المغرب", "أذكار النوم" to "قبل النوم", "أذكار بعد الصلاة" to "بعد كل صلاة", "الورد القرآني" to "حدد وردك اليومي", "الصلوات الخمس" to "متابعة الصلوات")
    var checked by remember { mutableStateOf(setOf<String>()) }
    Column(modifier.fillMaxSize().padding(18.dp)) { Text("العبادات والأذكار", color=White, fontSize=24.sp, fontWeight=FontWeight.Bold); Text("ثبات وطمأنينة", color=Gold); Spacer(Modifier.height(16.dp)); items.forEach { (name,sub) -> Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(14.dp), modifier=Modifier.fillMaxWidth().padding(bottom=9.dp)) { Row(Modifier.padding(14.dp), verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(name,color=White,fontWeight=FontWeight.SemiBold); Text(sub,color=Muted,fontSize=12.sp) }; Checkbox(checked=name in checked,onCheckedChange={ checked=if(it) checked+name else checked-name }, colors=CheckboxDefaults.colors(checkedColor=Gold)) } } } }
}
@Composable fun MoreScreen(modifier: Modifier) {
    val modules = listOf("العادات اليومية" to "متابعة الالتزام والسلاسل", "التطوير والتعلم" to "كتب ودورات ومهارات", "المشاريع والأعمال" to "أفكار ومراحل ومصاريف", "إدارة الأموال" to "الدخل والمصروف والادخار", "إدارة الوقت" to "تحليل توزيع ساعاتك", "التركيز" to "جلسات عمل دون مشتتات", "دفتر الأفكار" to "ملاحظات ويوميات", "المراجعة والتقارير" to "تقييم يومي وأسبوعي وشهري", "لوحة الرؤية" to "صور وأهداف المستقبل", "الإعدادات والنسخ الاحتياطي" to "حماية بياناتك وتصديرها")
    Column(modifier.fillMaxSize().padding(18.dp)) { Text("مساحتك الشخصية", color=White, fontSize=24.sp, fontWeight=FontWeight.Bold); Text("أدوات SHAMIKH LIFE", color=Muted); Spacer(Modifier.height(16.dp)); LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)) { items(modules) { (title,desc) -> Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(14.dp)) { Row(Modifier.fillMaxWidth().padding(15.dp),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title,color=White,fontWeight=FontWeight.SemiBold); Text(desc,color=Muted,fontSize=12.sp) }; Icon(Icons.Default.ChevronLeft,null,tint=Gold) } } } } }
}
@Composable fun TaskRow(task: TaskItem,onDone:(Long)->Unit) { Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(14.dp),modifier=Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically) { Checkbox(task.done,{onDone(task.id)},colors=CheckboxDefaults.colors(checkedColor=Gold)); Column(Modifier.weight(1f)) { Text(task.title,color=if(task.done) Muted else White,fontWeight=FontWeight.Medium); Text(SimpleDateFormat("HH:mm - dd/MM",Locale.getDefault()).format(Date(task.time)),color=Gold,fontSize=12.sp) }; if(task.done) Icon(Icons.Default.CheckCircle,null,tint=Gold) else Icon(Icons.Default.Alarm,null,tint=Muted) } } }
@Composable fun GoalRow(goal: GoalItem) { Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(14.dp),modifier=Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) { Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Text(goal.title,color=White,fontWeight=FontWeight.SemiBold); Text(goal.period,color=Gold,fontSize=12.sp) }; LinearProgressIndicator(progress={goal.progress/100f},color=Gold,trackColor=Color(0xFF38382F),modifier=Modifier.fillMaxWidth()); Text("${goal.progress}% مكتمل",color=Muted,fontSize=11.sp) } } }
@Composable fun EmptyCard(title:String,desc:String) { Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Text(title,color=White,fontWeight=FontWeight.Bold); Text(desc,color=Muted,fontSize=13.sp) } } }

@Composable fun AddTaskDialog(onDismiss:()->Unit,onSave:(String,Long)->Unit) {
    val context= LocalContext.current; var title by remember { mutableStateOf("") }; var time by remember { mutableLongStateOf(System.currentTimeMillis()+3600000) }
    AlertDialog(onDismissRequest=onDismiss,containerColor=Panel,title={Text("مهمة جديدة",color=White)},text={ Column(verticalArrangement=Arrangement.spacedBy(12.dp)) { OutlinedTextField(title,{title=it},label={Text("اسم المهمة")},singleLine=true); OutlinedButton(onClick={ val c=Calendar.getInstance().apply { timeInMillis=time }; TimePickerDialog(context,{_,h,m -> c.set(Calendar.HOUR_OF_DAY,h);c.set(Calendar.MINUTE,m);c.set(Calendar.SECOND,0);time=c.timeInMillis },c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show() },modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.AccessTime,null); Spacer(Modifier.width(8.dp)); Text("موعد التذكير: "+SimpleDateFormat("HH:mm - dd/MM",Locale.getDefault()).format(Date(time))) } } },confirmButton={TextButton(onClick={if(title.isNotBlank()) onSave(title.trim(),time)},enabled=title.isNotBlank()){Text("حفظ",color=Gold)}},dismissButton={TextButton(onClick=onDismiss){Text("إلغاء",color=Muted)}})
}
@Composable fun AddGoalDialog(onDismiss:()->Unit,onSave:(String,String)->Unit) { var title by remember { mutableStateOf("") }; var period by remember { mutableStateOf("شهري") }; AlertDialog(onDismissRequest=onDismiss,containerColor=Panel,title={Text("هدف جديد",color=White)},text={Column { OutlinedTextField(title,{title=it},label={Text("ما الهدف الذي تريد تحقيقه؟")}); Spacer(Modifier.height(8.dp)); Text("المدة",color=Muted); Row(horizontalArrangement=Arrangement.spacedBy(5.dp)) { listOf("يومي","أسبوعي","شهري","سنوي","طويل الأمد").forEach { FilterChip(selected=period==it,onClick={period=it},label={Text(it)},colors=FilterChipDefaults.filterChipColors(selectedContainerColor=Gold,selectedLabelColor=Bg)) } } }},confirmButton={TextButton(onClick={if(title.isNotBlank()) onSave(title,period)},enabled=title.isNotBlank()){Text("حفظ",color=Gold)}},dismissButton={TextButton(onClick=onDismiss){Text("إلغاء",color=Muted)}}) }

fun loadTasks(c:Context):List<TaskItem> = try { val a=JSONArray(c.getSharedPreferences("shamikh",0).getString("tasks","[]")); (0 until a.length()).map { val o=a.getJSONObject(it); TaskItem(o.getLong("id"),o.getString("title"),o.getLong("time"),o.getBoolean("done")) } } catch(_:Exception){ emptyList() }
fun saveTasks(c:Context,list:List<TaskItem>) { val a=JSONArray(); list.forEach { a.put(JSONObject().put("id",it.id).put("title",it.title).put("time",it.time).put("done",it.done)) }; c.getSharedPreferences("shamikh",0).edit().putString("tasks",a.toString()).apply() }
fun loadGoals(c:Context):List<GoalItem> = try { val a=JSONArray(c.getSharedPreferences("shamikh",0).getString("goals","[]")); (0 until a.length()).map { val o=a.getJSONObject(it); GoalItem(o.getLong("id"),o.getString("title"),o.getString("period"),o.getInt("progress")) } } catch(_:Exception){ emptyList() }
fun saveGoals(c:Context,list:List<GoalItem>) { val a=JSONArray(); list.forEach { a.put(JSONObject().put("id",it.id).put("title",it.title).put("period",it.period).put("progress",it.progress)) }; c.getSharedPreferences("shamikh",0).edit().putString("goals",a.toString()).apply() }
fun scheduleReminder(c:Context,item:TaskItem) { val alarm=c.getSystemService(Context.ALARM_SERVICE) as AlarmManager; val i=Intent(c,ReminderReceiver::class.java).putExtra("title",item.title).putExtra("id",item.id.toInt()); val pi=PendingIntent.getBroadcast(c,item.id.toInt(),i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE); try { if(Build.VERSION.SDK_INT>=31 && !alarm.canScheduleExactAlarms()) { alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,item.time,pi); val settings=Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${c.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(settings) } else alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,item.time,pi) } catch(_:SecurityException) { alarm.set(AlarmManager.RTC_WAKEUP,item.time,pi) } }
fun createChannel(c:Context) { if(Build.VERSION.SDK_INT>=26) { val nm=c.getSystemService(NotificationManager::class.java); nm.createNotificationChannel(NotificationChannel("shamikh_reminders","تذكيرات SHAMIKH LIFE",NotificationManager.IMPORTANCE_HIGH).apply { description="تنبيهات المهام والمواعيد" }) } }
